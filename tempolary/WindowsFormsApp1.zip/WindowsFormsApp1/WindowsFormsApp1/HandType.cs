﻿namespace WindowsFormsApp1
{
    internal enum HandType
    {
        Second,
        Minute,
        Hour,
    }
}
