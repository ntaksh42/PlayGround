﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class AnalogClock : UserControl
    {
        private IEnumerable<ClockHand> _hands = new List<ClockHand>();
        private readonly PointF _centerPoint;

        public AnalogClock()
        {
            InitializeComponent();

            var centerX = _pictureBox.Width / 2f;
            var centerY = _pictureBox.Height / 2f;
            _centerPoint = new PointF(centerX, centerY);

            InitHands();
        }

        private void InitHands()
        {
            _hands = new List<ClockHand>
            {
                new ClockHand(HandType.Second, _centerPoint, new Pen(Color.Black, 3f), 80),
                new ClockHand(HandType.Minute, _centerPoint, new Pen(Color.Red, 3f), 60),
                new ClockHand(HandType.Hour,_centerPoint, new Pen(Color.Brown, 3f), 40),
            };
        }

        public void DrawClock()
        {
            using (var g = _pictureBox.CreateGraphics())
            {
                g.Clear(Color.White);
                foreach (var h in _hands)
                {
                    h.Draw(g, DateTime.Now);
                }
            }
        }
    }
}
