﻿namespace WindowsFormsApp1
{
    partial class MainForm
    {
        /// <summary>
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージド リソースを破棄する場合は true を指定し、その他の場合は false を指定します。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナーで生成されたコード

        /// <summary>
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this._btnCircle = new System.Windows.Forms.Button();
            this._btnRect = new System.Windows.Forms.Button();
            this.userControl11 = new WindowsFormsApp1.MyCanvas();
            this._btnTrig = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // _btnCircle
            // 
            this._btnCircle.Location = new System.Drawing.Point(22, 20);
            this._btnCircle.Name = "_btnCircle";
            this._btnCircle.Size = new System.Drawing.Size(75, 23);
            this._btnCircle.TabIndex = 1;
            this._btnCircle.Text = "〇";
            this._btnCircle.UseVisualStyleBackColor = true;
            this._btnCircle.Click += new System.EventHandler(this._btnCircle_Click);
            // 
            // _btnRect
            // 
            this._btnRect.Location = new System.Drawing.Point(22, 49);
            this._btnRect.Name = "_btnRect";
            this._btnRect.Size = new System.Drawing.Size(75, 23);
            this._btnRect.TabIndex = 4;
            this._btnRect.Text = "□";
            this._btnRect.UseVisualStyleBackColor = true;
            this._btnRect.Click += new System.EventHandler(this._btnRect_Click);
            // 
            // userControl11
            // 
            this.userControl11.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.userControl11.Location = new System.Drawing.Point(123, 20);
            this.userControl11.Name = "userControl11";
            this.userControl11.Size = new System.Drawing.Size(105, 84);
            this.userControl11.TabIndex = 5;
            // 
            // _btnTrig
            // 
            this._btnTrig.Location = new System.Drawing.Point(22, 78);
            this._btnTrig.Name = "_btnTrig";
            this._btnTrig.Size = new System.Drawing.Size(75, 23);
            this._btnTrig.TabIndex = 6;
            this._btnTrig.Text = "△";
            this._btnTrig.UseVisualStyleBackColor = true;
            this._btnTrig.Click += new System.EventHandler(this._btnTrig_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(22, 107);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 7;
            this.button1.Text = "クリア";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.ClientSize = new System.Drawing.Size(265, 131);
            this.Controls.Add(this.button1);
            this.Controls.Add(this._btnTrig);
            this.Controls.Add(this.userControl11);
            this.Controls.Add(this._btnRect);
            this.Controls.Add(this._btnCircle);
            this.Name = "MainForm";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button _btnCircle;
        private System.Windows.Forms.Button _btnRect;
        private MyCanvas userControl11;
        private System.Windows.Forms.Button _btnTrig;
        private System.Windows.Forms.Button button1;
    }
}

