﻿using System;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void _btnCircle_Click(object sender, EventArgs e)
        {
            userControl11.DrawCircle();
        }

        private void _btnRect_Click(object sender, EventArgs e)
        {
            userControl11.DrawRectangle();
        }

        private void _btnTrig_Click(object sender, EventArgs e)
        {
            userControl11.DrawTriangle();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            userControl11.Clear();
        }
    }
}
