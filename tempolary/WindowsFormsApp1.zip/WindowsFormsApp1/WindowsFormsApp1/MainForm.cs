﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
            _timer1.Interval = 1000;
            _timer1.Tick += Timer1_Tick;
            _timer1.Start();
        }

        private void Timer1_Tick(object sender, EventArgs e)
        {
            _clockCanvas.DrawClock();
        }
    }
}
