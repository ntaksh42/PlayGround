﻿using System;
using System.Drawing;

namespace WindowsFormsApp1
{
    internal class ClockHand
    {
        private const int MAX_HOUR = 12;
        private const int MAX_MINITE = 60; 

        private readonly PointF _startPoint;
        private readonly int _length;
        private readonly Pen _pen;
        private readonly HandType _type;

        public ClockHand(HandType type, PointF point, Pen pen, int length)
        {
            _type = type;
            _startPoint = point;
            _pen = pen;
            _length = length;
        }

        internal void Draw(Graphics g, DateTime datetime)
        {
            var degree = TimeToDegree(datetime);
            var endPoint = CalcEndPoint(degree);
            g.DrawLine(_pen, _startPoint, endPoint);
        }

        private PointF CalcEndPoint(double degree)
        {
            int x2 = (int)_startPoint.X + (int)(Math.Cos(Math.PI * degree / 180.0 - (Math.PI / 2)) * _length);
            int y2 = (int)_startPoint.Y + (int)(Math.Sin(Math.PI * degree / 180.0 - (Math.PI / 2)) * _length);
            return new PointF((float)x2, (float)y2);
        }

        private double TimeToDegree(DateTime dateTime)
        {
            double second = dateTime.Second;
            double minute = dateTime.Minute; 
            double hour = dateTime.Hour % MAX_HOUR;
            var rate = _type.GetRate();
            switch (_type)
            {
                case HandType.Second:
                    return second * rate;
                case HandType.Minute:
                    return (minute * rate) + (second * (rate / MAX_MINITE));
                case HandType.Hour:
                    return (hour * rate) + (minute * 0.5) + (second * (0.5 / MAX_MINITE));
                default:
                    throw new NotSupportedException();
            }
        }
    }
}
