﻿using System.Drawing;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class MyCanvas : UserControl
    {
        public MyCanvas()
        {
            InitializeComponent();
        }

        public void DrawCircle()
        {
            Clear();
            using (var g = pictureBox1.CreateGraphics())
            {
                var x = pictureBox1.Width / 4;
                var y = pictureBox1.Height / 4;
                g.DrawEllipse(Pens.Red, x, y, pictureBox1.Width / 2, pictureBox1.Height / 2);
            }
        }

        public void DrawRectangle()
        {
            Clear();
            using (var g = pictureBox1.CreateGraphics())
            {
                var x = pictureBox1.Width / 4;
                var y = pictureBox1.Height / 4;
                g.DrawRectangle(Pens.Black, x, y, pictureBox1.Width / 2, pictureBox1.Height / 2);
            }
        }

        public void DrawTriangle()
        {
            Clear();
            using (var g = pictureBox1.CreateGraphics())
            {
                var x = pictureBox1.Width / 4;
                var y = pictureBox1.Height / 4;
                var points = new Point[]
                {
                    new Point(x*2, y),
                    new Point(x, y*3),
                    new Point(x*3, y*3),
                };

                g.DrawPolygon(Pens.Blue, points);
            }
        }

        public void Clear()
        {
            using (var g = pictureBox1.CreateGraphics())
            {
                g.FillRectangle(Brushes.White, new Rectangle(0, 0, pictureBox1.Width, pictureBox1.Height));
            }
        }
    }
}
